package com.examplest.standardProject;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class StandardProjectApplicationTests {

	@Test
	void contextLoads() {
	}

}
