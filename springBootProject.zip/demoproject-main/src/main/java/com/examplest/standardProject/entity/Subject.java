/**
 * 
 */
package com.examplest.standardProject.entity;

import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonIgnore;

import lombok.Getter;
import lombok.Setter;

/**
 * @author Dhanvantari Joshi
 */

@Entity
@Table(name = "subject")
@Getter
@Setter
public class Subject extends Auditable {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "subject_id")
	private Integer subjectId;

	@Column(name = "subject_name")
	private String subjectName;
	
	@OneToMany(mappedBy = "subject")
	@JsonIgnore
	private List<Task> tasks;

}
