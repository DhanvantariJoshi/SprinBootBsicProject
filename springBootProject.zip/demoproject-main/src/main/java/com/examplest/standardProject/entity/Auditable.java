/**
 * 
 */
package com.examplest.standardProject.entity;

import static java.time.LocalDateTime.now;
import static java.util.Objects.nonNull;
import static org.springframework.security.core.context.SecurityContextHolder.getContext;

import java.time.LocalDateTime;

import javax.persistence.Column;
import javax.persistence.Embeddable;
import javax.persistence.MappedSuperclass;
import javax.persistence.PrePersist;
import javax.persistence.PreRemove;
import javax.persistence.PreUpdate;

import lombok.Getter;
import lombok.Setter;

/**
 * @author Dhanvantari Joshi
 * @since 16-Feb-2024
 */

@Getter
@Setter
@Embeddable
@MappedSuperclass
public class Auditable {
	
	@Column(name = "created_by", nullable = false, updatable = false)
	private String createdBy;

	@Column(name = "created_date", nullable = false, columnDefinition = "TIMESTAMP", updatable = false)
	private LocalDateTime createdDate;

	@Column(name = "updated_by")
	private String updatedBy;

	@Column(name = "updated_date", columnDefinition = "TIMESTAMP")
	private LocalDateTime updatedDate;

	@Column(name = "deleted_by")
	protected String deletedBy;

	@Column(name = "deleted_date", columnDefinition = "TIMESTAMP")
	private LocalDateTime deletedDate;

	@PrePersist
	public void beforPersist() {
		if (nonNull(getContext()) && nonNull(getContext().getAuthentication())
				&& nonNull(getContext().getAuthentication().getName())) {
			this.createdBy = getContext().getAuthentication().getName();
		}
		this.createdDate = now();
	}

	@PreUpdate
	public void beforUpdate() {
		if (nonNull(getContext()) && nonNull(getContext().getAuthentication())
				&& nonNull(getContext().getAuthentication().getName())) {
			this.updatedBy = getContext().getAuthentication().getName();
		}
		this.updatedDate = now();
	}

	@PreRemove
	public void beforDelete() {
		if (nonNull(getContext()) && nonNull(getContext().getAuthentication())
				&& nonNull(getContext().getAuthentication().getName())) {
			this.deletedBy = getContext().getAuthentication().getName();
		}
		this.deletedDate = now();
	}

}
