/**
 * 
 */
package com.examplest.standardProject.exception;

import lombok.Getter;
import lombok.Setter;

/**
 * @author Dhanvantari Joshi
 */

@Setter @Getter
public class DemoException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = 5021018050700314536L;
	private final ApiError error;
	private final Exception exception;

	public DemoException(String message) {
		this.error = new ApiError();
		this.exception = new Exception();

	}

	public DemoException(ApiError error, Exception exception) {

		super(exception);
		this.error = error;
		this.exception = exception;

	}

}
