package com.examplest.standardProject.enums;

public enum ApiKey {

	MESSAGE("message"), SUCCESS("SUCCESS"), DATA("DATA"), TOKEN("token");

	String value;

	ApiKey(String value) {
		this.value = value;
	}

	public String val() {
		return value;
	}

}
