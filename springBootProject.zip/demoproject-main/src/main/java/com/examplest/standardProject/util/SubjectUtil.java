/**
 * 
 */
package com.examplest.standardProject.util;

import com.examplest.standardProject.dto.SubjectDto;
import com.examplest.standardProject.dtomapper.SubjectDtoMapper;
import com.examplest.standardProject.entity.Subject;

/**
 * @author Dhanvantari Joshi
 */

public class SubjectUtil {

	public static Subject toSubject(SubjectDto subjectDto) throws Exception {
		return SubjectDtoMapper.TO_SUBJECT.apply(subjectDto)
				.orElseThrow(() -> new Exception("Unable to convert subjectdto into subject Entity"));
	}
}
