/**
 * 
 */
package com.examplest.standardProject.Repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.examplest.standardProject.entity.Subject;

/**
 * @author Dhanvantari Joshi
 */

@Repository
public interface SubjectRepo extends JpaRepository<Subject, Integer>{

}
