package com.examplest.standardProject.service;


import org.springframework.stereotype.Service;

import com.examplest.standardProject.Repository.TaskRepo;
@Service
public interface TaskService extends TaskRepo{

}
