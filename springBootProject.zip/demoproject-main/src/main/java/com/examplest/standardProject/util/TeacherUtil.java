package com.examplest.standardProject.util;

import com.examplest.standardProject.dto.TeacherDto;
import com.examplest.standardProject.dtomapper.TeacherDtoMapper;
import com.examplest.standardProject.entity.Teacher;

public class TeacherUtil {

	
	public static Teacher toTeacher(TeacherDto teacherDto) throws Exception {
		return TeacherDtoMapper.TO_TEACHER.apply(teacherDto)
				.orElseThrow(() -> new Exception("Unable to convert subjectdto into subject Entity"));
	}
}
