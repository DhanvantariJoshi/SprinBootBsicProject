package com.examplest.standardProject.Repository;

import org.springframework.data.jpa.repository.JpaRepository;

import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.examplest.standardProject.entity.Student;

@Repository
public interface StudentRepo extends JpaRepository<Student, Integer>{

	@Query(nativeQuery = true, value="select * from Student where Stud_id= :sId")
	Student findByStudId(Integer sId);
	
//	@Query(nativeQuery = true, value="select * from Student where user_id= :userId")
//	public Student findByUsername(Integer userId);
	
	Student findByLoginId(Integer id);
}
