package com.examplest.standardProject.dto;

import lombok.Data;

/**
 * @author Dhanvantari Joshi
 */

@Data
public class SubjectDto {

	private Integer subjectId;

	private String subjectName;

}
