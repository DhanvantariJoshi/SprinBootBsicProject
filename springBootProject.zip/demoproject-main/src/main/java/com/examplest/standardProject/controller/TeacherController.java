package com.examplest.standardProject.controller;

import static com.examplest.standardProject.constant.ErrorConstants.RECORD_ADDED;
import static com.examplest.standardProject.constant.StandardConstant.MESSAGE;
import static com.examplest.standardProject.constant.StandardConstant.SUCCESS;
import static com.examplest.standardProject.constant.StandardConstant.DATA;
import static com.examplest.standardProject.constant.ApiUrl.Teacher;
import static com.examplest.standardProject.constant.ApiUrl.All_Teacher;
import static com.examplest.standardProject.constant.ApiUrl.Teacher_ById;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;
import com.examplest.standardProject.entity.Teacher;
import com.examplest.standardProject.service.TeacherService;

@RestController
public class TeacherController {
//	private static final Logger log = LogManager.getLogger(TeacherController.class);
//
//	@Autowired
//	private TeacherService teacherService;
//	
//	@PostMapping(Teacher)
//	public ResponseEntity<Map<String, Object>>saveTeacher(@RequestBody Teacher teacher){
//		Map<String, Object> map = new HashMap<>();
//		try {
//			teacherService.save(teacher);
//			map.put(SUCCESS, true);
//			map.put(MESSAGE, RECORD_ADDED);
//			
//		}catch(Exception ex) {
//			map.put(SUCCESS, false);
//			log.error("exception occur during task insertion");
//		}
//		log.info("Exiting from saveEmployee() function...");
//		return ResponseEntity.ok(map);
//	}
//	
//	@GetMapping(All_Teacher)
//	public ResponseEntity<Map<String, Object>>getAllTeacher(){
//		Map<String, Object> map = new HashMap<>();
//		try {
//			List l=teacherService.findAll();
//			map.put(SUCCESS, true);
//			map.put(MESSAGE, RECORD_ADDED);
//			map.put(DATA, l);
//		}
//		catch(Exception ex)
//		{
//			map.put(SUCCESS, false);
//			log.error("exception occur during task insertion");
//		}
//		log.info("Exiting from saveEmployee() function...");
//		return ResponseEntity.ok(map);
//		
//	}
//	
//	@GetMapping(Teacher_ById)
//	public ResponseEntity<Map<String, Object>>getByIs(@PathVariable ("teacherId") Integer teId){
//		Map<String, Object> map = new HashMap<>();
//		try {
//			Teacher teacher=teacherService.findByID(teId);
//			map.put(SUCCESS, true);
//			map.put(MESSAGE, RECORD_ADDED);
//			map.put(DATA, teacher);
//		}
//		catch(Exception ex)
//		{
//			map.put(SUCCESS, false);
//			log.error("exception occur during task insertion");
//		}
//		log.info("Exiting from saveEmployee() function...");
//		return ResponseEntity.ok(map);
//	}
//	
//	@PutMapping(Teacher_ById)
//	public ResponseEntity<Map<String, Object>>updateByIs(@PathVariable ("teacherId") Integer teId
//			,@RequestBody Teacher teacher1){
//		Map<String, Object> map = new HashMap<>();
//		try {
//			Teacher teacher=teacherService.findByID(teId);
//			teacher.setTeachName(teacher1.getTeachName());
//			teacher.setTeachProf(teacher1.getTeachProf());
//			teacherService.save(teacher);
//			map.put(SUCCESS, true);
//			map.put(MESSAGE, RECORD_ADDED);
//			map.put(DATA, teacher);
//		}
//		catch(Exception ex)
//		{
//			map.put(SUCCESS, false);
//			log.error("exception occur during task insertion");
//		}
//		log.info("Exiting from saveEmployee() function...");
//		return ResponseEntity.ok(map);
//	}
}