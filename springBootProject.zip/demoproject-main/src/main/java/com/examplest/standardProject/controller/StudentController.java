package com.examplest.standardProject.controller;

import static com.examplest.standardProject.constant.ApiUrl.Student;
import static com.examplest.standardProject.constant.ErrorConstants.RECORD_ADDED;
import static com.examplest.standardProject.enums.ApiKey.SUCCESS;
import static com.examplest.standardProject.enums.ApiKey.MESSAGE;

import java.util.EnumMap;

import org.modelmapper.ModelMapper;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.examplest.standardProject.StudentDto;
import com.examplest.standardProject.enums.ApiKey;
import com.examplest.standardProject.exception.ApiError;
import com.examplest.standardProject.exception.DemoException;
import com.examplest.standardProject.service.ExceptionService;
import com.examplest.standardProject.service.Studentservice;

import lombok.extern.slf4j.Slf4j;

@RestController
@Slf4j
public class StudentController {

	private ExceptionService exceptionService;
	private Studentservice studentservice;

	ModelMapper modelMapper = new ModelMapper();

	@PostMapping(Student)
	public ResponseEntity<EnumMap<ApiKey, Object>> saveStudent(@RequestBody StudentDto studentDto) throws Exception {
		EnumMap<ApiKey, Object> map = new EnumMap<>(ApiKey.class);

		try {
			log.info("Exiting from saveEmployee() function...");
			studentservice.saveStudent(studentDto);
			map.put(SUCCESS, true);
			map.put(MESSAGE, RECORD_ADDED);

		} catch (Exception ex) {
			String message = "exception occur during task insertion";
			log.info(message);
			exceptionService.saveException(new DemoException(new ApiError(message, ex), ex));
		}

		return ResponseEntity.ok(map);
	}

//	@GetMapping(All_Student)
//	public ResponseEntity<Map<String, Object>>getStudent(){
//		Map<String, Object> map = new HashMap<>();
//		try {
//			List l=studentservice.findAll();
//			map.put(SUCCESS, true);
//			map.put(MESSAGE, RECORD_ADDED);
//			map.put(DATA, l);
//		}catch(Exception ex) {
//			
//			map.put(SUCCESS, false);
//			log.error("exception occur during task insertion");
//		}
//		log.info("Exiting from saveEmployee() function...");
//		return ResponseEntity.ok(map);
//	}
//	
//	@PutMapping(Student_ById)
//	public ResponseEntity<Map<String, Object>>getById(@PathVariable ("studentId") Integer sId,
//			@RequestBody StudentDto studentDto){
//		Map<String, Object> map = new HashMap<>();
//		try {
//			Student student=studentservice.findByID(sId);
//			student.setAssignDate(studentDto.getAssignDate());
//			student.setSubmitDate(studentDto.getSubmitDate());
//			Task task=new Task();
//			Teacher teacher=new Teacher();
//			task.setTaskId(studentDto.getTask_id());
//			teacher.setTeachId(studentDto.getTeach_id());
//			student.setTask(task);
//			student.setTeacher(teacher);
//			studentservice.save(student);
//			map.put(SUCCESS, true);
//			map.put(MESSAGE, RECORD_ADDED);
//		}catch(Exception ex) {
//			map.put(SUCCESS, false);
//			log.error("exception occur during task insertion");
//		}
//		log.info("Exiting from saveEmployee() function...");
//		return ResponseEntity.ok(map);
//	}
//	
//	@GetMapping(Student_ById)
//	public ResponseEntity<Map<String, Object>>byId(@PathVariable ("studentId") Integer sId){
//		Map<String, Object> map = new HashMap<>();
//		try {
//			Student student=studentservice.findByID(sId);
//			map.put(SUCCESS, true);
//			map.put(MESSAGE, RECORD_ADDED);
//			map.put(DATA, student);
//		}catch(Exception ex) {
//			map.put(SUCCESS, false);
//			log.error("exception occur during task insertion");
//		}
//		log.info("Exiting from saveEmployee() function...");
//		return ResponseEntity.ok(map);
//	}
//	
//	@DeleteMapping(Student_ById)
//	public ResponseEntity<Map<String, Object>>DeletebyId(@PathVariable ("studentId") Integer sId){
//		Map<String, Object> map = new HashMap<>();
//		try {
//			studentservice.deleteById(sId);;
//			map.put(SUCCESS, true);
//			map.put(MESSAGE, RECORD_ADDED);
//			map.put(MESSAGE, RECORD_DELETED);
//		}catch(Exception ex) {
//			map.put(SUCCESS, false);
//			log.error("exception occur during task insertion");
//		}
//		log.info("Exiting from saveEmployee() function...");
//		return ResponseEntity.ok(map);
//	}
}
