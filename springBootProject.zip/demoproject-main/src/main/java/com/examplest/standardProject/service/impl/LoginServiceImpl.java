/**
 * 
 */
package com.examplest.standardProject.service.impl;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.examplest.standardProject.Repository.LoginRepo;
import com.examplest.standardProject.Repository.StudentRepo;
import com.examplest.standardProject.Repository.TeacherRepo;
import com.examplest.standardProject.dto.RegisterDto;
import com.examplest.standardProject.entity.Login;
import com.examplest.standardProject.entity.Student;
import com.examplest.standardProject.entity.Teacher;
import com.examplest.standardProject.service.LoginService;

/**
 * 
 */

@Service
public class LoginServiceImpl implements LoginService {

	@Autowired
	private ModelMapper modelMapper;

	@Autowired
	private LoginRepo loginRepo;

	@Autowired
	private StudentRepo studentRepo;

	@Autowired
	private TeacherRepo teacherRepo;

	@Override
	public void doregister(RegisterDto registerDto) {
		Login login = modelMapper.map(registerDto, Login.class);
		if (login.getType().equalsIgnoreCase("Student")) {
			Student student = modelMapper.map(registerDto, Student.class);
			login = loginRepo.save(login);
			studentRepo.save(student);
		} else if (login.getType().equalsIgnoreCase("Teacher")) {
			Teacher teacher = modelMapper.map(registerDto, Teacher.class);
			login = loginRepo.save(login);
			teacherRepo.save(teacher);
		}
	}

}
