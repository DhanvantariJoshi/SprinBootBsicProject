/**
 * 
 */
package com.examplest.standardProject.dto;

import lombok.Data;

/**
 * @author Dhanvantari Joshi
 */

@Data
public class RegisterDto {

	private String userName;
	private String password;
	private String studentname;
	private int studentclass;
	private String teacherName;
	private String teacherProf;
	private String type;
}
