/**
 * 
 */
package com.examplest.standardProject.controller;

import static com.examplest.standardProject.constant.ApiUrl.ADD_SUBJECT;
import static com.examplest.standardProject.enums.ApiKey.DATA;
import static com.examplest.standardProject.enums.ApiKey.SUCCESS;

import java.util.EnumMap;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.examplest.standardProject.Repository.SubjectRepo;
import com.examplest.standardProject.dto.SubjectDto;
import com.examplest.standardProject.enums.ApiKey;
import com.examplest.standardProject.exception.ApiError;
import com.examplest.standardProject.exception.DemoException;
import com.examplest.standardProject.service.ExceptionService;
import com.examplest.standardProject.util.SubjectUtil;

import lombok.extern.slf4j.Slf4j;

/**
 * @author Dhanvantari Joshi
 */

@RestController
@RequestMapping("/")
@Slf4j
public class SubjectController {
	
	private ExceptionService exceptionService;
	
	@Autowired
	private SubjectRepo subjectRepo;
	
	@PostMapping(ADD_SUBJECT)
	public ResponseEntity<EnumMap<ApiKey, Object>> addSubject(@RequestBody SubjectDto subjectDto) throws Exception{
		EnumMap<ApiKey, Object> map=new EnumMap<>(ApiKey.class);
		
		try {
			log.info("adding subject.....");
			map.put(DATA, subjectRepo.save(SubjectUtil.toSubject(subjectDto)));
			map.put(SUCCESS, true);
			
		}catch(Exception ex) {
			String message="Exception while adding subject";
			log.info(message);
			exceptionService.saveException(new DemoException(new ApiError(message, ex), ex));
		}
		
		return ResponseEntity.ok(map);
	}

}
