/**
 * 
 */
package com.examplest.standardProject.service.impl;

import org.modelmapper.ModelMapper;
import org.springframework.stereotype.Service;

import com.examplest.standardProject.StudentDto;
import com.examplest.standardProject.Repository.StudentRepo;
import com.examplest.standardProject.entity.Student;
import com.examplest.standardProject.service.Studentservice;

/**
 * @author Dhanvantari Joshi
 */

@Service
public class StudentServiceImpl implements Studentservice{
	
	private ModelMapper modelMapper;
	private StudentRepo studentRepo;

	@Override
	public void saveStudent(StudentDto studentDto) {
		
		Student student=modelMapper.map(studentDto, Student.class);
		studentRepo.save(student);
		
	}

}
