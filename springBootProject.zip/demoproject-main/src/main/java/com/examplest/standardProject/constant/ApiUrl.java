package com.examplest.standardProject.constant;

public class ApiUrl {
	// Standard project API Url constants 
	
	public static final String Student = "/student";
	public static final String Teacher = "/teacher";
	public static final String Task = "/task";
	public static final String Student_ById = "/student/{studentId}";
	public static final String Teacher_ById = "/teacher/{teacherId}";
	public static final String Task_ById = "/task/{taskId}";
	public static final String All_Task = "/getAllTaskList";
	public static final String All_Student = "/getAllStudentList";
	public static final String All_Teacher = "/getAllTeacherList";
	
	/* for subject controller*/
	public static final String ADD_SUBJECT="/addSubject";
	
	/* for register controller*/
	public static final String REGISTER="/register";
}
