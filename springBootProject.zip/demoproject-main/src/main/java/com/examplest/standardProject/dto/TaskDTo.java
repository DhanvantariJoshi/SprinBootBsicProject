/**
 * 
 */
package com.examplest.standardProject.dto;

import java.util.List;

import com.examplest.standardProject.entity.Student;

import lombok.Data;

/**
 * @author Dhanvantari Joshi
 */

@Data
public class TaskDTo {

	private int taskId;

	private String taskname;

	private String taskDetail;

	private String timeReq;

	private List<Student> students;
}
