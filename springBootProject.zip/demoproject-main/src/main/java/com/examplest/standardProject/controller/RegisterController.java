/**
 * 
 */
package com.examplest.standardProject.controller;

import static com.examplest.standardProject.constant.ApiUrl.REGISTER;
import static com.examplest.standardProject.enums.ApiKey.MESSAGE;
import static com.examplest.standardProject.enums.ApiKey.SUCCESS;

import java.util.EnumMap;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.examplest.standardProject.dto.RegisterDto;
import com.examplest.standardProject.enums.ApiKey;
import com.examplest.standardProject.exception.ApiError;
import com.examplest.standardProject.exception.DemoException;
import com.examplest.standardProject.service.ExceptionService;
import com.examplest.standardProject.service.LoginService;

import lombok.extern.slf4j.Slf4j;

/**
 * @author Dhanvantari Joshi
 */

@RestController
@Slf4j
@RequestMapping("/")
public class RegisterController {

	private ExceptionService exceptionService;
	private LoginService loginService;

	@PostMapping(REGISTER)
	public ResponseEntity<EnumMap<ApiKey, Object>> doRegister(@RequestBody RegisterDto registerDto) throws Exception {

		EnumMap<ApiKey, Object> map = new EnumMap<>(ApiKey.class);

		try {
			log.info("save the user");
			loginService.doregister(registerDto);
			map.put(SUCCESS, true);
			map.put(MESSAGE, "added sucessfully....!");
		} catch (Exception ex) {

			String message = "Error while register";
			log.info(message);
			exceptionService.saveException(new DemoException(new ApiError(message, ex), ex));
		}

		return ResponseEntity.ok(map);
	}

}
