package com.examplest.standardProject.exception.handler;

import static org.apache.commons.lang3.exception.ExceptionUtils.getRootCauseMessage;
import static org.apache.commons.lang3.exception.ExceptionUtils.getStackTrace;
import static org.springframework.http.HttpStatus.INTERNAL_SERVER_ERROR;

import java.util.Arrays;

import org.springframework.http.HttpHeaders;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.context.request.ServletRequestAttributes;
import org.springframework.web.context.request.WebRequest;
import org.springframework.web.servlet.mvc.method.annotation.ResponseEntityExceptionHandler;

import com.examplest.standardProject.exception.ApiError;
import com.examplest.standardProject.util.HttpUtils;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

@ControllerAdvice
@RequiredArgsConstructor
@ResponseBody
@Slf4j
public class GlobalExceptionHandler extends ResponseEntityExceptionHandler{
	
	@ExceptionHandler({ Exception.class })
	public ResponseEntity<Object> handleAll(Exception ex, WebRequest request) {
		ApiError apiError = new ApiError(INTERNAL_SERVER_ERROR, ex.getLocalizedMessage(),
				Arrays.asList("Something went wrong", getRootCauseMessage(ex), ex.getLocalizedMessage() , getStackTrace(ex)));
		apiError.setPath(HttpUtils.getFullURL(((ServletRequestAttributes) request).getRequest()));
		log.error("handleAll api error: {}", apiError);
		return new ResponseEntity<>(apiError, new HttpHeaders(), apiError.getResponseStatus());
	}

}
