/**
 * 
 */
package com.examplest.standardProject.util;
import com.examplest.standardProject.dto.StudentDto;
import com.examplest.standardProject.dtomapper.StudentDtoMapper;
import com.examplest.standardProject.entity.Student;

/**
 * @author Dhanvantari Joshi
 */
public class StudentUtil {
	
	public static Student toStudent(StudentDto studentDto) throws Exception {
		return StudentDtoMapper.TO_STUDENT.apply(studentDto)
				.orElseThrow(() -> new Exception("Unable to convert subjectdto into subject Entity"));
	}

}
