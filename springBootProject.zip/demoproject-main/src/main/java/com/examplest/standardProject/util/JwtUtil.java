package com.examplest.standardProject.util;

import java.util.Date;
import java.util.HashMap;
import java.util.Map;
import java.util.function.Function;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.stereotype.Service;

import com.examplest.standardProject.Repository.LoginRepo;
import com.examplest.standardProject.Repository.StudentRepo;
import com.examplest.standardProject.Repository.TeacherRepo;
import com.examplest.standardProject.entity.Login;
import com.examplest.standardProject.entity.Student;
import com.examplest.standardProject.entity.Teacher;

import io.jsonwebtoken.Claims;
import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.SignatureAlgorithm;

@Service
public class JwtUtil {

	@Autowired
	StudentRepo studentRepo;

	@Autowired
	LoginRepo loginRepo;

	@Autowired
	TeacherRepo teacherRepo;

	private static final long serialVersionUID = 2550185165626007488L;

	public static final long JWT_TOKEN_VALIDITY = 15 * 60 * 60;

	private String SECRET_KEY = "secret234567asdfghj";

	public String extractUsername(String token) {
		return extractClaim(token, Claims::getSubject);
	}

	public Date extractExpiration(String token) {
		return extractClaim(token, Claims::getExpiration);
	}

	public <T> T extractClaim(String token, Function<Claims, T> claimsResolver) {
		final Claims claims = extractAllClaims(token);
		return claimsResolver.apply(claims);
	}

	private Claims extractAllClaims(String token) {
		return Jwts.parser().setSigningKey(SECRET_KEY).parseClaimsJws(token).getBody();
	}

	private Boolean isTokenExpired(String token) {
		return extractExpiration(token).before(new Date());
	}

	public String generateToken(UserDetails userDetails) {
		Map<String, Object> claims = new HashMap<>();

		Login login = loginRepo.findByUsername(userDetails.getUsername());
		if (login.getType().equalsIgnoreCase("Student")) {
			Student student = studentRepo.findByLoginId(login.getId());
			if (student != null) {
				claims.put("id", student.getStudId());
				claims.put("name", student.getStudentname());
				claims.put("Class", student.getStudentclass());
				claims.put("assign date", student.getAssignDate());
				claims.put("submission date", student.getSubmitDate());
				claims.put("task", student.getTask().getTaskDetail());
				claims.put("assigned by", student.getTeacher().getTeachName());
			}
		} else {
			Teacher teacher = teacherRepo.findByLoginId(login.getId());
			if (teacher != null) {
				claims.put("name", teacher.getTeachName());
				claims.put("profession", teacher.getTeachProf());
				claims.put("Student", teacher.getStudents());
			}
		}
		return createToken(claims, userDetails.getUsername());
	}

	private String createToken(Map<String, Object> claims, String subject) {
		Login login = loginRepo.findByUsername(subject);
		if (login.getType().equalsIgnoreCase("Student")) {
			Student student = studentRepo.findByLoginId(login.getId());
			if (student != null) {
				claims.put("id", student.getStudId());
				claims.put("name", student.getStudentname());
				claims.put("Class", student.getStudentclass());
				claims.put("assign date", student.getAssignDate());
				claims.put("submission date", student.getSubmitDate());
				claims.put("task", student.getTask().getTaskDetail());
				claims.put("assigned by", student.getTeacher().getTeachName());
			}
		} else {
			Teacher teacher = teacherRepo.findByLoginId(login.getId());
			if (teacher != null) {
				claims.put("name", teacher.getTeachName());
				claims.put("profession", teacher.getTeachProf());
				claims.put("Student", teacher.getStudents());
			}
		}
		return Jwts.builder().setClaims(claims).setSubject(subject).setIssuedAt(new Date(System.currentTimeMillis()))
				.setExpiration(new Date(System.currentTimeMillis() + 1000 * 60 * 60 * 10))
				.signWith(SignatureAlgorithm.HS256, SECRET_KEY).compact();
	}

	public Boolean validateToken(String token, UserDetails userDetails) {
		final String username = extractUsername(token);
		return (username.equals(userDetails.getUsername()) && !isTokenExpired(token));
	}
}
