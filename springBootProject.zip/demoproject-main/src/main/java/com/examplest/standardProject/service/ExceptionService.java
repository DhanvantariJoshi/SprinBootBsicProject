/**
 * 
 */
package com.examplest.standardProject.service;

import org.springframework.transaction.annotation.Transactional;

import com.examplest.standardProject.exception.DemoException;

/**
 * @author Dhanvantari Joshi
 */

@Transactional(readOnly = true)
public interface ExceptionService {

	@Transactional
	void saveException(DemoException ex) throws Exception;
}
