package com.examplest.standardProject.dto;

import com.examplest.standardProject.entity.Task;
import com.examplest.standardProject.entity.Teacher;

import lombok.Getter;
import lombok.Setter;

/**
 * @author Dhanvantari Joshi
 * @since 16-Feb-2024
 */

@Getter
@Setter
public class StudentDto {

	private int studId;

	private String sname;

	private int sclass;

	private String assignDate;

	private String submitDate;

	private String userName;

	private String password;

	private Teacher teacher;

	private Task task;

}
