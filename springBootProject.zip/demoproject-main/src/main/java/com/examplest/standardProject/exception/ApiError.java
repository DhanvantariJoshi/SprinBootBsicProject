package com.examplest.standardProject.exception;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.apache.commons.lang3.exception.ExceptionUtils;
import org.springframework.http.HttpStatus;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Data;

@Data
public class ApiError {

	private HttpStatus responseStatus;
	@JsonProperty("SUCCESS")
	private boolean success;
	@JsonProperty("DATA")
	private String data;
	private String path;
	@JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "dd-MM-yyyy hh:mm:ss")
	private LocalDateTime timestamp;
	private String message;
	private List<String> messages = new ArrayList<>();
	private List<String> errors = new ArrayList<>();

	public ApiError() {
		timestamp = LocalDateTime.now();
	}

	public ApiError(String message, Throwable ex) {

		this();
		this.message = message;
		errors = Arrays.asList(message, ex.getLocalizedMessage(), ex.getMessage(), ExceptionUtils.getMessage(ex));

	}

	public ApiError(HttpStatus responseStatus, String message, List<String> errors) {
		this();
		this.responseStatus=responseStatus;
		this.message=message;
		this.errors=errors;
		
	}

}
