package com.examplest.standardProject.constant;

public class ErrorConstants {
	public static final String RECORD_FOUND="Record found";
	public static final String RECORD_NOT_FOUND ="Record not found";
	public static final String ERROR_IN_ADDING_DATA = "Error while adding data";
	public static final String ERROR_IN_FETCHING_DATA = "Error while getting Data";
	public static final String ERROR_IN_UPDATEING_DATA ="Erorr while updating data";
	public static final String ERROR_IN_DELETING_DATA ="Error while deleting data";
	public static final String 	RECORD_ADDED ="Record added successfully";
	public static final String 	RECORD_DELETED ="Record deleted successfully";
	public static final String 	RECORD_UPDATED ="Record updated successfully";

}
