package com.examplest.standardProject.entity;

import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToMany;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonIgnore;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@Entity
@Table(name = "Task")
public class Task extends Auditable {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "task_id", unique = true, nullable = false)
	private int taskId;

	@Column(name = "task_name")
	private String taskname;

	@Column(name = "task_Detail")
	private String taskDetail;

	@Column(name = "time_req")
	private String timeReq;

	@OneToMany(mappedBy = "task")
	@JsonIgnore
	private List<Student> students;
	
	@ManyToOne
	@JoinColumn(name="subject_id")
	private Subject subject;

}