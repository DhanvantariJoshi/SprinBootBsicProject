/**
 * 
 */
package com.examplest.standardProject.dtomapper;

import static com.examplest.standardProject.util.FunctionUtil.evalMapper;

import java.util.Optional;
import java.util.function.Function;

import com.examplest.standardProject.dto.TeacherDto;
import com.examplest.standardProject.entity.Teacher;

/**
 * 
 */
public class TeacherDtoMapper {
	
	private TeacherDtoMapper() {
		
	}
	
	public static final Function<TeacherDto, Optional<Teacher>> TO_TEACHER = e -> evalMapper(e,
			Teacher.class);

}
