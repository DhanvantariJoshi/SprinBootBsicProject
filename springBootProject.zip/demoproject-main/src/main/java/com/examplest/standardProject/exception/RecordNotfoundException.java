package com.examplest.standardProject.exception;

public class RecordNotfoundException extends DemoException {

	/**
	 * 
	 */
	private static final long serialVersionUID = 8345987489690682224L;

	public RecordNotfoundException(ApiError apiError, Exception exception) {
		super(apiError, exception);
	}

	public RecordNotfoundException(String message) {
		super(message);
	}

}
