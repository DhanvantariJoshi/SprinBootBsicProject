/**
 * 
 */
package com.examplest.standardProject.Repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.examplest.standardProject.entity.Login;

/**
 * @author Dhanvantari Joshi
 */

@Repository
public interface LoginRepo extends JpaRepository<Login, Integer>{
	
	@Query(nativeQuery = true, value="select * from user_details where user_name= :username")
	Login findByUsername(String username);

}
