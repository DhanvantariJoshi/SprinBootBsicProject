package com.examplest.standardProject.service;

import org.springframework.stereotype.Service;

import com.examplest.standardProject.Repository.TeacherRepo;
import com.examplest.standardProject.entity.Teacher;
@Service
public interface TeacherService{


}
