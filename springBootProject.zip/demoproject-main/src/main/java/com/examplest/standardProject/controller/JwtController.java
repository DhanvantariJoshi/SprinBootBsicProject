package com.examplest.standardProject.controller;

import static com.examplest.standardProject.enums.ApiKey.DATA;
import static com.examplest.standardProject.enums.ApiKey.SUCCESS;

import java.util.EnumMap;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.examplest.standardProject.dto.LoginDto;
import com.examplest.standardProject.enums.ApiKey;
import com.examplest.standardProject.exception.ApiError;
import com.examplest.standardProject.exception.DemoException;
import com.examplest.standardProject.service.ExceptionService;
import com.examplest.standardProject.service.UserTokenService;
import com.examplest.standardProject.util.JwtUtil;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

@RequiredArgsConstructor
@RestController
@Slf4j
public class JwtController {

	@Autowired(required = true)
	AuthenticationManager authenticationManager;

	@Autowired
	UserTokenService userTokenService;

	@Autowired
	JwtUtil jwtUtil;

	private ExceptionService exceptionService;

	@PostMapping("/token")
	public ResponseEntity<EnumMap<ApiKey, Object>> getToken(@RequestBody LoginDto login) throws Exception {
		EnumMap<ApiKey, Object> map = new EnumMap<>(ApiKey.class);

		try {
			this.authenticationManager
					.authenticate(new UsernamePasswordAuthenticationToken(login.getUserName(), login.getPassword()));
			UserDetails userDetails = userTokenService.loadUserByUsername(login.getUserName());
			String token = this.jwtUtil.generateToken(userDetails);
			map.put(DATA, token);
			map.put(SUCCESS, "sucess");
		} catch (Exception ex) {
			String message = "Bad credentials while login";
			log.info(message);
			exceptionService.saveException(new DemoException(new ApiError(message, ex), ex));
		}

		return ResponseEntity.ok(map);
	}

}
