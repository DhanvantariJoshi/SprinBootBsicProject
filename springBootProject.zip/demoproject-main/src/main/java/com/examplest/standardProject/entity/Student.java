package com.examplest.standardProject.entity;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import lombok.Getter;
import lombok.Setter;

/**
 * @author Dhanvantari Joshi
 * @since 16-Feb-2024
 */

@Entity
@Table(name = "Student")
@Getter
@Setter
public class Student extends Auditable {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "Stud_id", unique = true, nullable = false)
	private int studId;

	@Column(name = "Student_name")
	private String studentname;

	@Column(name = "Student_class")
	private int studentclass;

	@Column(name = "assign_date")
	private String assignDate;

	@Column(name = "submit_date")
	private String submitDate;

	@ManyToOne
	@JoinColumn(name = "teacher_id")
	private Teacher teacher;

	@ManyToOne
	@JoinColumn(name = "task_id")
	private Task task;
	
	@OneToOne
    @JoinColumn(name = "user_id")
	private Login login;

}
