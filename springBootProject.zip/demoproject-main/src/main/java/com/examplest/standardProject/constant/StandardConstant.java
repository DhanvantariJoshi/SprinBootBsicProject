package com.examplest.standardProject.constant;

import java.text.DateFormat;
import java.text.SimpleDateFormat;

public class StandardConstant {
	public static final DateFormat DATEFORMAT = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
	public static final  String SUCCESS = "success";
	public static final  String MESSAGE = "message";
	public static final String DATA="data";
	public static final String EXCEPTION="exception";
	public static final String RECORD="record";
}
