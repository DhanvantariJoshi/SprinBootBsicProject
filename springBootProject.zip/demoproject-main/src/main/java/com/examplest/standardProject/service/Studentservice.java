package com.examplest.standardProject.service;

import com.examplest.standardProject.StudentDto;

public interface Studentservice{

	void saveStudent(StudentDto studentDto);	

}
