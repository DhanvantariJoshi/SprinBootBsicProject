package com.examplest.standardProject.controller;

import static com.examplest.standardProject.constant.StandardConstant.SUCCESS;
import static com.examplest.standardProject.constant.StandardConstant.DATA;
import static com.examplest.standardProject.constant.StandardConstant.MESSAGE;
import static com.examplest.standardProject.constant.ErrorConstants.RECORD_ADDED;
import static com.examplest.standardProject.constant.ErrorConstants.RECORD_FOUND;
import static com.examplest.standardProject.constant.ApiUrl.Task;
import static com.examplest.standardProject.constant.ApiUrl.All_Task;
import static com.examplest.standardProject.constant.ApiUrl.Task_ById;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.examplest.standardProject.Repository.TaskRepo;
import com.examplest.standardProject.entity.Task;
import com.examplest.standardProject.service.TaskService;


@RestController
public class TaskController {
	
//	private static final Logger log = LogManager.getLogger(TaskController.class);
//	
//	@Autowired
//	TaskService taskService;
//	
//	@PostMapping(Task)
//	public ResponseEntity<Map<String, Object>>saveTask(@RequestBody Task task){
//		Map<String, Object> map = new HashMap<>();
//		try {
//			taskService.save(task);
//			map.put(SUCCESS, true);
//			map.put(MESSAGE, RECORD_ADDED);
//			
//		}catch(Exception ex) {
//			map.put(SUCCESS, false);
//			log.error("exception occur during task insertion");
//		}
//		log.info("Exiting from saveEmployee() function...");
//		return ResponseEntity.ok(map);
//	}
//	
//	@GetMapping(All_Task)
//	public ResponseEntity<Map<String, Object>> getAlltask(){
//		Map<String, Object> map = new HashMap<>();
//		try {
//			List l=taskService.findAll();
//			map.put(SUCCESS, true);
//			map.put(MESSAGE, RECORD_FOUND);
//			map.put(DATA, l);
//		}catch(Exception ex)
//		{
//			map.put(SUCCESS, false);
//			log.error("exception occur during task insertion");
//		}
//		log.info("Exiting from saveEmployee() function...");
//		return ResponseEntity.ok(map);
//	}
//
//	@GetMapping(Task_ById)
//	public ResponseEntity<Map<String, Object>> gettaskById(@PathVariable ("taskId") Integer tId){
//		Map<String, Object> map = new HashMap<>();
//		try {
//			Task task = taskService.findByID(tId);
//			map.put(SUCCESS, true);
//			map.put(MESSAGE, RECORD_FOUND);
//			map.put(DATA, task);
//		}catch(Exception ex)
//		{
//			map.put(SUCCESS, false);
//			log.error("exception occur during task insertion");
//		}
//		log.info("Exiting from saveEmployee() function...");
//		return ResponseEntity.ok(map);
//	}
//	
//	@PutMapping(Task_ById)
//	public ResponseEntity<Map<String, Object>> updateById(@PathVariable ("taskId") Integer tId,
//			@RequestBody Task task1){
//		Map<String, Object> map = new HashMap<>();
//		try {
//			Task task = taskService.findByID(tId);
//			task.setTaskDetail(task1.getTaskDetail());
//			task.setTimeReq(task1.getTimeReq());
//			taskService.save(task);
//			map.put(SUCCESS, true);
//			map.put(MESSAGE, RECORD_FOUND);
//			map.put(DATA, task);
//		}catch(Exception ex)
//		{
//			map.put(SUCCESS, false);
//			log.error("exception occur during task insertion");
//		}
//		log.info("Exiting from saveEmployee() function...");
//		return ResponseEntity.ok(map);
//	}
}
