/**
 * 
 */
package com.examplest.standardProject.dtomapper;

import java.util.Optional;
import java.util.function.Function;
import static com.examplest.standardProject.util.FunctionUtil.evalMapper;
import com.examplest.standardProject.dto.SubjectDto;
import com.examplest.standardProject.entity.Subject;

/**
 * @author Dhanvantari Joshi
 */
public class SubjectDtoMapper {
	
	private SubjectDtoMapper() {
		
	}
		
	public static final Function<SubjectDto, Optional<Subject>> TO_SUBJECT = e -> evalMapper(e,
			Subject.class);

}
