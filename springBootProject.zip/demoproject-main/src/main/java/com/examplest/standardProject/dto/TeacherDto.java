/**
 * 
 */
package com.examplest.standardProject.dto;

import java.util.List;

import com.examplest.standardProject.entity.Student;

import lombok.Data;

/**
 * @author Dhanvantari Joshi
 */

@Data
public class TeacherDto {

	private int teachId;

	private String teachName;

	private String teachProf;

	private List<Student> students;

}
