package com.examplest.standardProject.Repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.examplest.standardProject.entity.Task;


@Repository
public interface TaskRepo extends JpaRepository<Task, Integer>{

	@Query(nativeQuery = true, value="select * from task where task_id= :tId")
	Task findByID(Integer tId);
}
