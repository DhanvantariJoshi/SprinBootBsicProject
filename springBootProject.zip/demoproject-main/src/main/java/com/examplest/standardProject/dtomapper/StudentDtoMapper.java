/**
 * 
 */
package com.examplest.standardProject.dtomapper;

import java.util.Optional;
import java.util.function.Function;
import static com.examplest.standardProject.util.FunctionUtil.evalMapper;
import com.examplest.standardProject.dto.StudentDto;
import com.examplest.standardProject.entity.Student;

/**
 * 
 */
public class StudentDtoMapper {
	
	private StudentDtoMapper() {
		
	}
	
	public static final Function<StudentDto, Optional<Student>> TO_STUDENT = e -> evalMapper(e,
			Student.class);

}
