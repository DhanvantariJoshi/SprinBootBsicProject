package com.examplest.standardProject.Repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.examplest.standardProject.entity.Teacher;
@Repository
public interface TeacherRepo extends JpaRepository<Teacher, Integer>{

	@Query(nativeQuery = true, value="select * from Teacher where teach_id= :teId")
	Teacher findByID(Integer teId);
	
//	@Query(nativeQuery = true, value="select * from teacher where user_id= :userId")
//	Student findByUsername(Integer userId);
	
	Teacher findByLoginId(Integer id);
}
