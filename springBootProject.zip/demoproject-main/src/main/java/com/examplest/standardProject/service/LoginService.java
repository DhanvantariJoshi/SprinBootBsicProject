/**
 * 
 */
package com.examplest.standardProject.service;

import org.springframework.stereotype.Service;

import com.examplest.standardProject.Repository.LoginRepo;
import com.examplest.standardProject.dto.RegisterDto;

/**
 * @author Dhanvantari Joshi
 */


public interface LoginService {

	void doregister(RegisterDto registerDto);

}
