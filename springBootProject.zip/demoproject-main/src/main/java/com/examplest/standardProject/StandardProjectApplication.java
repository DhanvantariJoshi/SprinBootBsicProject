package com.examplest.standardProject;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class StandardProjectApplication {

	public static void main(String[] args) {
		SpringApplication.run(StandardProjectApplication.class, args);
	}

}
